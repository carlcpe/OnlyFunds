<?php
include('header.php');
checkUser();
userArea();

function getTotalExpenses() {
    global $con;
    $query = "SELECT SUM(price) AS total_expenses FROM expense WHERE added_by = '".$_SESSION['UID']."'";
    $result = mysqli_query($con, $query);

    if (!$result) {
        die("Query Failed: " . mysqli_error($con));
    }

    $row = mysqli_fetch_assoc($result);
    return $row['total_expenses'] ?? 0; // Return 0 if null
}

function getTotalIncome() {
    global $con;
    $query = "SELECT SUM(amount) AS total_income FROM income WHERE user_id = '".$_SESSION['UID']."'";
    $result = mysqli_query($con, $query);

    if (!$result) {
        die("Query Failed: " . mysqli_error($con));
    }

    $row = mysqli_fetch_assoc($result);
    return $row['total_income'] ?? 0; // Return 0 if null
}

function getWalletBalance() {
    global $con;
    $query = "SELECT balance FROM wallet WHERE user_id = '".$_SESSION['UID']."'";
    $result = mysqli_query($con, $query);

    if (!$result) {
        die("Query Failed: " . mysqli_error($con));
    }

    $row = mysqli_fetch_assoc($result);
    return $row['balance'] ?? 0; // Return 0 if null
}

function updateWalletBalance($newBalance) {
    global $con;
    $updateQuery = "UPDATE wallet SET balance = $newBalance WHERE user_id = '".$_SESSION['UID']."'";
    $updateResult = mysqli_query($con, $updateQuery);

    if (!$updateResult) {
        die("Update Failed: " . mysqli_error($con));
    }
}

// Calculate totals and update wallet balance
$totalExpenses = getTotalExpenses();
$totalIncome = getTotalIncome();
$difference = $totalIncome - $totalExpenses;
$walletBalance = getWalletBalance(); // Get current wallet balance

$newWalletBalance = $difference;
updateWalletBalance($newWalletBalance);

// Reload wallet balance after update
$walletBalance = getWalletBalance(); // Refresh wallet balance

?>

<div class="main-content">
   <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Wallet Balance</strong>
                        </div>
                        <div class="card-body">
                            <p class="balance">Current Balance: $<?php echo number_format($walletBalance, 2); ?></p>
                            <hr>
                            <h5 class="card-title">Summary</h5>
                            <p class="card-text">Total Income: $<?php echo number_format($totalIncome, 2); ?></p>
                            <p class="card-text">Total Expenses: $<?php echo number_format($totalExpenses, 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
