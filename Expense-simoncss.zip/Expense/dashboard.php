<?php
include('header.php');
checkUser();
userArea();



function getExpensesByCategory() {
   global $con;  // Assuming $con is your database connection
   $query = "SELECT category.name AS category, SUM(expense.price) AS total 
             FROM expense 
             INNER JOIN category ON expense.category_id = category.id 
             WHERE expense.added_by = '".$_SESSION['UID']."'
             GROUP BY expense.category_id";
   $result = mysqli_query($con, $query);
   $data = [];
   while ($row = mysqli_fetch_assoc($result)) {
       $data[] = $row;
   }
   return $data;
}
function getIncomesByCategory() {
   global $con;
   $query = "SELECT income_categories.name AS category, SUM(income.amount) AS total 
             FROM income 
             INNER JOIN income_categories ON income.category_id = income_categories.id 
             WHERE income.user_id = '".$_SESSION['UID']."'
             GROUP BY income.category_id";
   $result = mysqli_query($con, $query);
   $data = [];
   while ($row = mysqli_fetch_assoc($result)) {
       $data[] = $row;
   }
   return $data;
}



$expensesByCategory = getExpensesByCategory();
$incomesByCategory = getIncomesByCategory();
?>

<script>
    setTitle("Dashboard");
    selectLink('dashboard_link');
    document.addEventListener('DOMContentLoaded', (event) => {
    // Expense by category doughnut chart
    const expenseChartData = <?php echo json_encode($expensesByCategory); ?>;
    const expenseLabels = expenseChartData.map(item => item.category);
    const expenseData = expenseChartData.map(item => parseFloat(item.total));

    new Chart(document.getElementById('expenseByCategoryChart'), {
        type: 'doughnut',
        data: {
            labels: expenseLabels,
            datasets: [{
                data: expenseData,
                backgroundColor: ['#FFFF4D', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
                hoverBackgroundColor: ['#FFFF4D', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
            }]
        },
        options: {
            responsive: true,
            legend: {
                position: 'top',
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });

    // Income by category doughnut chart
    const incomeChartData = <?php echo json_encode($incomesByCategory); ?>;
    const incomeLabels = incomeChartData.map(item => item.category);
    const incomeData = incomeChartData.map(item => parseFloat(item.total));

    new Chart(document.getElementById('incomeByCategoryChart'), {
        type: 'doughnut',
        data: {
            labels: incomeLabels,
            datasets: [{
                data: incomeData,
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
                hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
            }]
        },
        options: {
            responsive: true,
            legend: {
                position: 'top',
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });
});
</script>
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <!-- Expense by Category Chart -->
                <div class="col-lg-6">
                    <div class="overview-item overview-item--c1"> <!-- css tag for cards -->
                        <div class="overview__inner">
                            <div class="overview-box clearfix">
                                <div class="text">
                                    <canvas id="expenseByCategoryChart"></canvas>
                                    <span>Expenses by Category</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Income by Category Chart -->
                <div class="col-lg-6">
                    <div class="overview-item overview-item--c1">
                        <div class="overview__inner">
                            <div class="overview-box clearfix">
                                <div class="text">
                                    <canvas id="incomeByCategoryChart"></canvas>
                                    <span>Incomes by Category</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <div class="col-sm-6 col-lg-3">
               <div class="overview-item overview-item--c1">
                  <div class="overview__inner">
                     <div class="overview-box clearfix">
                        <div class="text">
                           <h2><?php echo getDashboardExpense('today')?></h2>
                           <span>Today's Expense</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-6 col-lg-3">
               <div class="overview-item overview-item--c1">
                  <div class="overview__inner">
                     <div class="overview-box clearfix">
                        <div class="text">
                           <h2><?php echo getDashboardExpense('yesterday')?></h2>
                           <span>Yesterday's Expense</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-6 col-lg-3">
               <div class="overview-item overview-item--c1">
                  <div class="overview__inner">
                     <div class="overview-box clearfix">
                        <div class="text">
                           <h2><?php echo getDashboardExpense('week')?></h2>
                           <span>This Week Expense</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-6 col-lg-3">
               <div class="overview-item overview-item--c1">
                  <div class="overview__inner">
                     <div class="overview-box clearfix">
                        <div class="text">
                           <h2><?php echo getDashboardExpense('month')?></h2>
                           <span>This Month Expense</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-6 col-lg-3">
               <div class="overview-item overview-item--c1">
                  <div class="overview__inner">
                     <div class="overview-box clearfix">
                        <div class="text">
                           <h2><?php echo getDashboardExpense('year')?></h2>
                           <span>This Year Expense</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-6 col-lg-3">
               <div class="overview-item overview-item--c1">
                  <div class="overview__inner">
                     <div class="overview-box clearfix">
                        <div class="text">
                           <h2><?php echo getDashboardExpense('total')?></h2>
                           <span>Total Expense</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- END MAIN CONTENT-->
<!-- END PAGE CONTAINER-->
<?php
include('footer.php');
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', (event) => {
    // Expense by category doughnut chart
    const expenseChartData = <?php echo json_encode($expensesByCategory); ?>;
    const expenseLabels = expenseChartData.map(item => item.category);
    const expenseData = expenseChartData.map(item => parseFloat(item.total));

    new Chart(document.getElementById('expenseByCategoryChart'), {
        type: 'doughnut',
        data: {
            labels: expenseLabels,
            datasets: [{
                data: expenseData,
                backgroundColor: ['#FFFF4D', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
                hoverBackgroundColor: ['#FFFF4D', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
            }]
        },
        options: {
            responsive: true,
            legend: {
                position: 'top',
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });

    // Income by category doughnut chart
    const incomeChartData = <?php echo json_encode($incomesByCategory); ?>;
    // Assuming data structure change from category_id to category
   const incomeLabels = incomeChartData.map(item => item.category);

    const incomeData = incomeChartData.map(item => parseFloat(item.total));

    new Chart(document.getElementById('incomeByCategoryChart'), {
        type: 'doughnut',
        data: {
            labels: incomeLabels,
            datasets: [{
                data: incomeData,
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
                hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
            }]
        },
        options: {
            responsive: true,
            legend: {
                position: 'top',
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });
});
</script>

